/** SooaeShop deployment controller - independent Cloudflare Worker.
 * Deploy DEV/PROD Pages via Cloudflare Direct Upload, execute D1 SQL separately.
 * Cloudflare API credentials never reach the browser or the shopping-site assets.
 */
import { blake3 } from '@noble/hashes/blake3.js';
import PAGE_HTML from './ui-generated.js';

const API = 'https://api.cloudflare.com/client/v4';
const COOKIE_NAME = 'sooae_deploy_session';
const MAX_ZIP = 12 * 1024 * 1024;
const MAX_TOTAL_UNCOMPRESSED = 40 * 1024 * 1024;
const MAX_ENTRY = 8 * 1024 * 1024;
const MAX_FILES = 1000;
const SESSION_MS = 2 * 60 * 60 * 1000;
const enc = new TextEncoder();
const dec = new TextDecoder('utf-8', { fatal: true });

function responseJSON(value, status = 200, extra = {}) {
  return new Response(JSON.stringify(value), { status, headers: {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store', ...extra} });
}
function httpError(status, message) { const x=new Error(message); x.status=status; return x; }
function hex(bytes) { return Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join(''); }
async function sha256(str) { return hex(new Uint8Array(await crypto.subtle.digest('SHA-256',typeof str==='string'?enc.encode(str):str))); }
function eq(a,b) { if(typeof a!=='string'||typeof b!=='string')return false;let t=a.length^b.length; for(let i=0;i<Math.max(a.length,b.length);i++)t|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return t===0; }
function allowedEnv(v,env) { if(v==='dev')return {name:'DEV', project:env.DEV_PAGES_PROJECT||'sooae-shop-v27-test',d1:env.DEV_D1_ID};if(v==='prod')return {name:'PROD',project:env.PROD_PAGES_PROJECT||'suaeshop01',d1:env.PROD_D1_ID};throw httpError(400,'올바른 개발계 또는 운영계를 선택하세요.'); }
function requireConfig(env) { if(!env.DEPLOY_META || !env.DEPLOY_PASSWORD || !env.CF_API_TOKEN || !/^[a-f0-9]{32}$/i.test(env.CF_ACCOUNT_ID||''))throw httpError(503,'Worker의 DEPLOY_META/Secret/CF_ACCOUNT_ID 설정을 확인하세요.'); }
function clientIP(req){return (req.headers.get('CF-Connecting-IP')||'unknown').slice(0,70);}
function sessionCookie(v,clear=false) { return `${COOKIE_NAME}=${clear?'':v}; Path=/; HttpOnly; Secure; SameSite=Strict; ${clear?'Max-Age=0':'Max-Age=7200'}`; }
async function auth(req,env) {
  const token=(req.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE_NAME+'='))?.slice(COOKIE_NAME.length+1);
  if(!token || !/^[0-9a-f]{64}$/.test(token))throw httpError(401,'배포관리 로그인이 필요합니다.');
  const digest=await sha256(token);
  const record=await env.DEPLOY_META.prepare('SELECT actor FROM deploy_sessions WHERE token_hash=? AND expires_at>?').bind(digest,Date.now()).first();
  if(!record)throw httpError(401,'세션이 만료되었습니다. 다시 로그인하세요.');
  return {actor:record.actor, hash:digest};
}
function checkOrigin(req){
  const origin=req.headers.get('Origin');
  if(!origin || origin!==new URL(req.url).origin || req.headers.get('X-Sooae-Action')!=='1')throw httpError(403,'출처 검증에 실패했습니다.');
}
async function log(env,act,environment,status,detail,actor='admin',sha='') {
  await env.DEPLOY_META.prepare('INSERT INTO deploy_audit(at,actor,action,environment,status,detail,sha256) VALUES(?,?,?,?,?,?,?)')
  .bind(new Date().toISOString(),actor,act,environment,status,String(detail||'').slice(0,900),String(sha||'')) .run();
}
async function cf(path,token,options={}) {
  const resp=await fetch(API+path,{...options,headers:{'Authorization':'Bearer '+token,...(options.headers||{})}});
  const raw=await resp.text();let j;try{j=JSON.parse(raw)}catch{throw httpError(502,`Cloudflare API 응답 오류 (${resp.status})`)}
  if(!resp.ok || j.success===false){let brief=(j.errors||[]).map(e=>e.message).filter(Boolean).join('; ')||`HTTP ${resp.status}`; throw httpError(502,'Cloudflare API: '+brief.slice(0,350));}
  return j.result===undefined?j:j.result;
}
async function cfJSON(path,token,body) {return cf(path,token,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});}
async function cfPagesProject(env, target) {return cf(`/accounts/${env.CF_ACCOUNT_ID}/pages/projects/${target.project}`,env.CF_API_TOKEN);}
async function uploadJWT(env,target){const r=await cf(`/accounts/${env.CF_ACCOUNT_ID}/pages/projects/${target.project}/upload-token`,env.CF_API_TOKEN);if(!r.jwt)throw httpError(502,'Cloudflare 업로드 토큰이 없습니다.');return r.jwt;}
function b64(bytes){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);}
function crc32(bytes){let crc=0xffffffff;for(const b of bytes){crc^=b;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function validPath(p) {return p && p.length<=250 && !p.startsWith('/') && !p.startsWith('\\') && !p.includes('\\') && !p.includes('\0') && !p.split('/').some(c=>c==='..'||c==='.'||!c) && !p.startsWith('__MACOSX/');}
async function extractZip(bytes){
  const a=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes),dv=new DataView(a.buffer,a.byteOffset,a.byteLength);
  if(a.length>MAX_ZIP)throw httpError(413,'ZIP 파일은 최대 12MB입니다.');
  let end=-1;for(let p=a.length-22;p>=Math.max(0,a.length-65558);p--)if(dv.getUint32(p,true)===0x06054b50){end=p;break;}
  if(end<0)throw httpError(400,'유효한 ZIP 파일이 아닙니다.');
  if(dv.getUint16(end+4,true)||dv.getUint16(end+6,true))throw httpError(400,'다중 디스크 ZIP은 지원하지 않습니다.');
  const count=dv.getUint16(end+10,true),cdSize=dv.getUint32(end+12,true),cdStart=dv.getUint32(end+16,true);
  if(count>MAX_FILES || cdStart+cdSize>a.length)throw httpError(400,'ZIP 목록 또는 크기가 잘못되었습니다.');
  let cursor=cdStart,total=0;const files=[];
  for(let i=0;i<count;i++) {
    if(cursor+46>a.length||dv.getUint32(cursor,true)!==0x02014b50)throw httpError(400,'ZIP 중앙 디렉터리가 손상되었습니다.');
    const flags=dv.getUint16(cursor+8,true),method=dv.getUint16(cursor+10,true),crc=dv.getUint32(cursor+16,true),compressed=dv.getUint32(cursor+20,true),size=dv.getUint32(cursor+24,true);
    const nl=dv.getUint16(cursor+28,true),xl=dv.getUint16(cursor+30,true),cl=dv.getUint16(cursor+32,true),offset=dv.getUint32(cursor+42,true);
    if(cursor+46+nl+xl+cl>a.length)throw httpError(400,'ZIP 파일명 길이가 올바르지 않습니다.');
    const name=dec.decode(a.subarray(cursor+46,cursor+46+nl));cursor+=46+nl+xl+cl;
    if(name.endsWith('/'))continue;
    if(!validPath(name)||flags&1 || ![0,8].includes(method))throw httpError(400,`안전하지 않거나 지원하지 않는 ZIP 항목: ${name}`);
    if(size>MAX_ENTRY||compressed>MAX_ENTRY||total+size>MAX_TOTAL_UNCOMPRESSED)throw httpError(413,'ZIP 내부 파일 크기 한도를 초과했습니다.');
    total+=size;
    if(offset+30>a.length ||dv.getUint32(offset,true)!==0x04034b50)throw httpError(400,'ZIP 로컬 헤더가 손상되었습니다.');
    const pos=offset+30+dv.getUint16(offset+26,true)+dv.getUint16(offset+28,true);
    if(pos+compressed>a.length)throw httpError(400,'ZIP 압축 데이터가 손상되었습니다.');
    const src=a.subarray(pos,pos+compressed);let contents;
    if(method===0) contents=new Uint8Array(src);
    else {
      try {contents=new Uint8Array(await new Response(new Blob([src]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());}
      catch {throw httpError(400,`압축 해제 실패: ${name}`)}
    }
    if(contents.length!==size||crc32(contents)!==crc)throw httpError(400,`ZIP 무결성 검사에 실패했습니다: ${name}`);
    files.push({path:name,data:contents});
  }
  if(!files.length)throw httpError(400,'ZIP에 배포할 파일이 없습니다.');
  const roots=files.map(f=>f.path);
  if(!roots.includes('index.html') && roots.every(p=>p.includes('/'))){const prefix=roots[0].split('/')[0]+'/';if(roots.every(p=>p.startsWith(prefix)))for(const f of files)f.path=f.path.slice(prefix.length);}
  if(!files.some(f=>f.path==='index.html')||!files.some(f=>f.path==='admin/index.html')||!files.some(f=>f.path==='_worker.js'))
    throw httpError(400,'완전한 Pages 배포 ZIP이 아닙니다. index.html, admin/index.html, _worker.js가 필요합니다.');
  const seen=new Set();for(const f of files){if(!validPath(f.path)||seen.has(f.path))throw httpError(400,'ZIP 파일명이 중복되거나 올바르지 않습니다.');seen.add(f.path);}
  return files;
}
function guessMime(name){const ext=name.toLowerCase().split('.').pop();return ({html:'text/html; charset=utf-8',js:'application/javascript; charset=utf-8',css:'text/css; charset=utf-8',json:'application/json',txt:'text/plain; charset=utf-8',svg:'image/svg+xml',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',gif:'image/gif',ico:'image/x-icon',woff2:'font/woff2',pdf:'application/pdf',xml:'application/xml',webmanifest:'application/manifest+json'})[ext]||'application/octet-stream';}
function fileHash(file){const extension=file.path.includes('.')?file.path.split('.').pop():'';const input=enc.encode(b64(file.data)+extension);return hex(blake3(input)).slice(0,32);}
const specialSet=new Set(['_worker.js','_worker.bundle','_headers','_redirects','_routes.json','functions-filepath-routing-config.json']);
async function deployPages(files,env,target) {
  const project=await cfPagesProject(env,target);
  const branch=project.production_branch||'main';
  const jwt=await uploadJWT(env,target), special=new Map(), manifest={}, assetByHash=new Map();
  for(const f of files){
    if(specialSet.has(f.path)){special.set(f.path,f);continue;}
    const hash=fileHash(f);manifest['/'+f.path]=hash;if(!assetByHash.has(hash))assetByHash.set(hash,{key:hash,value:b64(f.data),base64:true,metadata:{contentType:guessMime(f.path)}});
  }
  if(!special.has('_worker.js')||special.has('_worker.bundle'))throw httpError(400,'_worker.js와 _worker.bundle을 동시에 또는 잘못 사용할 수 없습니다.');
  const hashes=[...assetByHash.keys()];if(hashes.length>20000)throw httpError(413,'파일이 너무 많습니다.');
  const missing=new Set(await cfJSON('/pages/assets/check-missing',jwt,{hashes}));
  let batch=[],weight=0;
  async function flush(){if(!batch.length)return;await cfJSON('/pages/assets/upload',jwt,batch);batch=[];weight=0;}
  for(const asset of assetByHash.values()){
    if(!missing.has(asset.key))continue;
    const length=asset.value.length+asset.key.length+120;
    if(weight+length>2*1024*1024)await flush();
    batch.push(asset);weight+=length;
  }
  await flush();await cfJSON('/pages/assets/upsert-hashes',jwt,{hashes});
  const form=new FormData();form.set('manifest',JSON.stringify(manifest));form.set('branch',branch);form.set('commit_dirty','true');form.set('commit_message','SooaeShop ZIP deployment via deploy manager');
  for(const [key,f] of special){form.set(key,new Blob([f.data],{type:guessMime(key)}),key);}
  const result=await cf(`/accounts/${env.CF_ACCOUNT_ID}/pages/projects/${target.project}/deployments`,env.CF_API_TOKEN,{method:'POST',body:form});
  return {id:result.id, url:result.url||'', aliases:result.aliases||[], branch,files:files.length,uploaded:missing.size};
}
async function login(req,env){
  const ip=await sha256(clientIP(req));
  const key=ip.slice(0,40);const current=Date.now();
  const row=await env.DEPLOY_META.prepare('SELECT attempts,blocked_until FROM deploy_auth_attempts WHERE actor=?').bind(key).first();
  if(row && row.blocked_until>current)throw httpError(429,'로그인 시도가 제한되었습니다. 15분 후 다시 시도하세요.');
  const body=await req.json(); const input=typeof body.password==='string'?body.password:'';
  const good=eq(await sha256(input),await sha256(env.DEPLOY_PASSWORD));
  if(!good){const attempts=(row?.attempts||0)+1;await env.DEPLOY_META.prepare('INSERT INTO deploy_auth_attempts(actor,attempts,blocked_until) VALUES(?,?,?) ON CONFLICT(actor) DO UPDATE SET attempts=excluded.attempts,blocked_until=excluded.blocked_until').bind(key,attempts,attempts>=5?current+900000:0).run();throw httpError(401,'비밀번호를 확인하세요.');}
  await env.DEPLOY_META.prepare('DELETE FROM deploy_auth_attempts WHERE actor=?').bind(key).run();
  const token=hex(crypto.getRandomValues(new Uint8Array(32)));
  await env.DEPLOY_META.prepare('INSERT INTO deploy_sessions(token_hash,actor,created_at,expires_at) VALUES(?,?,?,?)').bind(await sha256(token),'deploy-admin',current,current+SESSION_MS).run();
  return responseJSON({ok:true},200, {'Set-Cookie':sessionCookie(token)});
}
async function sqlExec(req,env,actor){
  const form=await req.formData(),name=String(form.get('environment')||'');const target=allowedEnv(name,env);
  if(!target.d1||!/^[a-f0-9-]{36}$/i.test(target.d1))throw httpError(503,'대상 D1 UUID를 설정하세요.');
  const file=form.get('file');if(!(file instanceof File)|| !/\.sql$/i.test(file.name)||file.size>500000||file.size<=0)throw httpError(400,'500KB 이하 .sql 파일을 선택하세요.');
  const sql=await file.text();if(!sql.trim())throw httpError(400,'빈 SQL입니다.');
  if(/\bATTACH\b|\bDETACH\b|\bVACUUM\b|\bPRAGMA\s+(?:writable_schema|journal_mode|foreign_keys)\b/i.test(sql))throw httpError(400,'보안 또는 유지보수에 위험한 SQL 구문이 포함되어 있습니다.');
  const hash=await sha256(sql),prev=await env.DEPLOY_META.prepare('SELECT id FROM deploy_audit WHERE action=? AND environment=? AND status=? AND sha256=? LIMIT 1').bind('sql',name,'success',hash).first();
  if(prev)throw httpError(409,'이미 성공적으로 실행한 SQL입니다. 중복 실행을 차단했습니다.');
  const expected=name==='prod'?'SQL PROD sooae.kr':'SQL DEV';
  if(String(form.get('confirmation'))!==expected)throw httpError(400,`확인 문구를 정확히 입력하세요: ${expected}`);
  if(name==='prod'&&form.get('backup_confirm')!=='yes')throw httpError(400,'운영 DB 백업 완료 확인이 필요합니다.');
  try{
    const result=await cfJSON(`/accounts/${env.CF_ACCOUNT_ID}/d1/database/${target.d1}/query`,env.CF_API_TOKEN,{sql});
    if(Array.isArray(result)&&result.some(r=>r.success===false))throw httpError(502,'D1 SQL 실행 결과에 실패가 포함되어 있습니다.');
    await log(env,'sql',name,'success',`${file.name} / ${sql.length}자`,actor,hash);
    return {ok:true, hash, statements:sql.split(';').filter(s=>s.trim()).length, resultSummary:'Cloudflare D1 쿼리 성공 응답 확인'};
  }catch(e){await log(env,'sql',name,'failed',e.message,actor,hash);throw e;}
}
async function doDeploy(req,env,actor){
  const form=await req.formData(),name=String(form.get('environment')||'');const target=allowedEnv(name,env);
  const expected=name==='prod'?'DEPLOY PROD sooae.kr':'DEPLOY DEV';
  if(form.get('confirmation')!==expected)throw httpError(400,`확인 문구를 정확히 입력하세요: ${expected}`);
  if(name==='prod'&&form.get('backup_confirm')!=='yes')throw httpError(400,'운영 전 검증·백업 완료 확인이 필요합니다.');
  const f=form.get('file');if(!(f instanceof File)||!/\.zip$/i.test(f.name)||!f.size||f.size>MAX_ZIP)throw httpError(400,'12MB 이하의 완전한 Pages 배포 ZIP을 선택하세요.');
  const zipBytes=new Uint8Array(await f.arrayBuffer());const hash=await sha256(zipBytes);
  const files=await extractZip(zipBytes);
  try{const info=await deployPages(files,env,target);await log(env,'deploy',name,'success',`${f.name} / ${info.id} / ${info.files} files`,actor,hash);return {ok:true,sha256:hash,...info};}
  catch(e){await log(env,'deploy',name,'failed',e.message,actor,hash);throw e;}
}
async function doRollback(req,env,actor){
  const {environment,id,confirmation}=await req.json();const target=allowedEnv(environment,env);
  if(!/^[a-zA-Z0-9-]{20,80}$/.test(id||''))throw httpError(400,'배포 ID가 올바르지 않습니다.');
  const expected=environment==='prod'?'ROLLBACK PROD sooae.kr':'ROLLBACK DEV';
  if(confirmation!==expected)throw httpError(400,`확인 문구: ${expected}`);
  const list=await cf(`/accounts/${env.CF_ACCOUNT_ID}/pages/projects/${target.project}/deployments?per_page=30`,env.CF_API_TOKEN);
  if(!Array.isArray(list)||!list.some(x=>x.id===id))throw httpError(400,'최근 배포 목록에 없는 ID입니다.');
  try{const result=await cf(`/accounts/${env.CF_ACCOUNT_ID}/pages/projects/${target.project}/deployments/${id}/rollback`,env.CF_API_TOKEN,{method:'POST'});await log(env,'rollback',environment,'success',id,actor);return {ok:true,id:result.id||id};}
  catch(e){await log(env,'rollback',environment,'failed',e.message,actor);throw e;}
}
async function status(req,env){const values=[];for(const key of ['dev','prod']){const t=allowedEnv(key,env);const item={environment:key,project:t.project,d1Configured:!!t.d1,pages:false,d1:false,domain:key==='prod'?'https://sooae.kr':'https://sooae-shop-v27-test.pages.dev'};try{const p=await cfPagesProject(env,t);item.pages=true;item.branch=p.production_branch||'';item.latestDeployment=p.canonical_deployment?.id||'';}catch(e){item.pagesError=e.message;}
  if(t.d1){try{const d=await cf(`/accounts/${env.CF_ACCOUNT_ID}/d1/database/${t.d1}`,env.CF_API_TOKEN);item.d1=!!(d.uuid||d.name);item.dbName=d.name||'';}catch(e){item.dbError=e.message;}}values.push(item);}return {ok:true,targets:values};}
async function getHistory(req,env){const u=new URL(req.url);const key=u.searchParams.get('environment')||'dev', t=allowedEnv(key,env);const rows=await env.DEPLOY_META.prepare('SELECT id,at,actor,action,environment,status,detail,sha256 FROM deploy_audit WHERE environment=? ORDER BY id DESC LIMIT 30').bind(key).all();let deploys=[];
  try{const result=await cf(`/accounts/${env.CF_ACCOUNT_ID}/pages/projects/${t.project}/deployments?per_page=10`,env.CF_API_TOKEN);deploys=(Array.isArray(result)?result:[]).map(d=>({id:d.id,created_on:d.created_on,environment:d.environment,url:d.url,latest_stage:d.latest_stage?.status}));}catch(e){return {ok:true,logs:rows.results||[],deploys,deployError:e.message};}
  return {ok:true,logs:rows.results||[],deploys};}
export default { async fetch(req,env){
  const path=new URL(req.url).pathname;try{
    requireConfig(env);
    if(path==='/'&&req.method==='GET'){
      const nonce=hex(crypto.getRandomValues(new Uint8Array(16)));
      const html=PAGE_HTML.replaceAll('__NONCE__',nonce);
      return new Response(html,{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':`default-src 'none'; script-src 'nonce-${nonce}'; style-src 'nonce-${nonce}'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`,'X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'}});
    }
    if(!path.startsWith('/api/'))return new Response('Not Found',{status:404});
    if(req.method==='POST')checkOrigin(req);
    if(path==='/api/login'&&req.method==='POST')return await login(req,env);
    const user=await auth(req,env);
    if(path==='/api/session'&&req.method==='GET')return responseJSON({ok:true,actor:user.actor});
    if(path==='/api/logout'&&req.method==='POST'){await env.DEPLOY_META.prepare('DELETE FROM deploy_sessions WHERE token_hash=?').bind(user.hash).run();return responseJSON({ok:true},200,{'Set-Cookie':sessionCookie('',true)});}
    if(path==='/api/status'&&req.method==='GET')return responseJSON(await status(req,env));
    if(path==='/api/history'&&req.method==='GET')return responseJSON(await getHistory(req,env));
    if(path==='/api/deploy'&&req.method==='POST')return responseJSON(await doDeploy(req,env,user.actor));
    if(path==='/api/sql'&&req.method==='POST')return responseJSON(await sqlExec(req,env,user.actor));
    if(path==='/api/rollback'&&req.method==='POST')return responseJSON(await doRollback(req,env,user.actor));
    throw httpError(404,'API 경로가 없습니다.');
  }catch(e){const status=e.status||500;return responseJSON({ok:false,error:status===500?'서버 처리 오류입니다. Worker 로그를 확인하세요.':String(e.message||'요청 오류')},status);}
}};
