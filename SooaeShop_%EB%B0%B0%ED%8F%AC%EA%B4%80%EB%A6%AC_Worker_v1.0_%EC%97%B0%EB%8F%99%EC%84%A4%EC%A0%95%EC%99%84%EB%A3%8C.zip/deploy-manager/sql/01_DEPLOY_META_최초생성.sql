-- Run ONCE in separate D1 database: sooae-deploy-meta-db (never in Shop DEV/PROD DB).
CREATE TABLE IF NOT EXISTS deploy_sessions (
 token_hash TEXT PRIMARY KEY, actor TEXT NOT NULL, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_deploy_sessions_expire ON deploy_sessions(expires_at);
CREATE TABLE IF NOT EXISTS deploy_auth_attempts (
 actor TEXT PRIMARY KEY, attempts INTEGER NOT NULL DEFAULT 0, blocked_until INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS deploy_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, actor TEXT NOT NULL,
 action TEXT NOT NULL, environment TEXT NOT NULL, status TEXT NOT NULL,
 detail TEXT NOT NULL DEFAULT '', sha256 TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_deploy_audit_env ON deploy_audit(environment,id DESC);
CREATE INDEX IF NOT EXISTS idx_deploy_audit_sql_hash ON deploy_audit(action,environment,status,sha256);
