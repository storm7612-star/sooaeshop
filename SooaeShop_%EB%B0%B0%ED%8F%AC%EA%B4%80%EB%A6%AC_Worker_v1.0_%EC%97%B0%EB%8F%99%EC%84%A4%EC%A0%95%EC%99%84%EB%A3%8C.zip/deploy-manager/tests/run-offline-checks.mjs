import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const base=path.resolve(import.meta.dirname,'..');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'sooae-manager-test-'));
let source=fs.readFileSync(path.join(base,'src','worker.js'),'utf8');
// Replace external hash library only for offline integration-protocol tests (no BLAKE3 hash accuracy claim).
source=source.replace("import { blake3 } from '@noble/hashes/blake3.js';", "import { createHash } from 'node:crypto'; const blake3 = bytes => new Uint8Array(createHash('sha256').update(bytes).digest());");
source += '\nexport { extractZip, validPath, crc32, allowedEnv };\n';
fs.copyFileSync(path.join(base,'src','ui-generated.js'),path.join(tmp,'ui-generated.js'));
fs.writeFileSync(path.join(tmp,'worker.mjs'),source);
fs.writeFileSync(path.join(tmp,'ui-generated.js'),fs.readFileSync(path.join(base,'src','ui-generated.js')));
fs.writeFileSync(path.join(tmp,'package.json'),'{"type":"module"}');
const mod=await import('file://'+path.join(tmp,'worker.mjs'));
assert.equal(mod.validPath('admin/index.html'),true);
for(const x of ['../x','a/../../x','/root','a\\file','a//b'])assert.equal(!!mod.validPath(x),false,x);
const zip=fs.readFileSync(process.argv[2] || path.join(base,'tests','fixtures','shop-test-pages.zip'));
const files=await mod.extractZip(zip);
assert(files.length>=4,'shop ZIP should extract');
for(const name of ['index.html','admin/index.html','_worker.js','order-app.js'])assert(files.some(x=>x.path===name),name);
assert(files.find(x=>x.path==='admin/index.html').data.length>0);
const broken=Buffer.from(zip);const dataOff=30+broken.readUInt16LE(26)+broken.readUInt16LE(28);broken[dataOff]^=0xff;
let corrupt=false;try{await mod.extractZip(broken);}catch(e){corrupt=true;}assert(corrupt,'corrupt ZIP must be rejected');
let recorded=[];
class DB {
 prepare(query){return {bind(...params){return {async first(){if(query.includes('FROM deploy_sessions'))return {actor:'admin'};return null;},async run(){return {success:true};},async all(){return {results:[]};}}}};}
}
const env={DEPLOY_META:new DB(),DEPLOY_PASSWORD:'test-only-long-secret',CF_API_TOKEN:'test-token',CF_ACCOUNT_ID:'0'.repeat(32),DEV_D1_ID:'11111111-1111-1111-1111-111111111111',PROD_D1_ID:'22222222-2222-2222-2222-222222222222'};
const fetchOriginal=globalThis.fetch;
globalThis.fetch=async (url,opts={})=>{
 const u=new URL(url);recorded.push({pathname:u.pathname,auth:opts.headers?.Authorization||'',method:opts.method||'GET'});
 const key='Bearer '+env.CF_API_TOKEN;
 let r;
 if(u.pathname.endsWith('/upload-token'))r={jwt:'temporary-jwt'};
 else if(u.pathname.endsWith('/pages/assets/check-missing'))r=[];
 else if(u.pathname.endsWith('/pages/assets/upsert-hashes'))r={};
 else if(u.pathname.includes('/pages/projects/')&&u.pathname.endsWith('/deployments')&&opts.method==='POST')r={id:'mock-deployment-id',url:'https://preview.pages.dev'};
 else if(u.pathname.includes('/pages/projects/')&&u.pathname.endsWith('/deployments'))r=[];
 else if(u.pathname.endsWith('/sooae-shop-v27-test'))r={name:'sooae-shop-v27-test',production_branch:'main'};
 else if(u.pathname.endsWith('/d1/database/11111111-1111-1111-1111-111111111111'))r={uuid:env.DEV_D1_ID,name:'sooae-shop-dev-db'};
 else if(u.pathname.includes('/d1/database/')&&opts.method==='POST')r=[{success:true}];
 else r={};
 return new Response(JSON.stringify({success:true,errors:[],result:r}),{status:200,headers:{'content-type':'application/json'}});
};
try{
 // Check unauthenticated request is refused, and no secret appears in HTML.
 let res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/status'),env);
 assert.equal(res.status,401);
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/'),env);
 assert.equal(res.status,200);const html=await res.text();
 assert(html.includes('ZIP 배포'));assert(!html.includes('test-token'));
 assert(html.includes('nonce='));
 // Login and ensure session cookie flag.
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/login',{method:'POST',headers:{Origin:'https://deploy.sooae.kr','X-Sooae-Action':'1','Content-Type':'application/json'},body:JSON.stringify({password:'test-only-long-secret'})}),env);
 assert.equal(res.status,200,'valid login');assert(res.headers.get('Set-Cookie').includes('HttpOnly; Secure; SameSite=Strict'));
 const token=res.headers.get('Set-Cookie').match(/sooae_deploy_session=([a-f0-9]+)/)[1];
 const authHeaders={'Cookie':'sooae_deploy_session='+token};
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/status',{headers:authHeaders}),env);
 assert.equal(res.status,200,'session auth');const status=(await res.json()).targets;assert.equal(status[0].pages,true);assert.equal(status[0].d1,true);
 // Wrong origin and operations without verification must not invoke external APIs.
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/deploy',{method:'POST',headers:{...authHeaders,Origin:'https://evil.invalid','X-Sooae-Action':'1'},body:new FormData()}),env);
 assert.equal(res.status,403,'cross-origin blocked');
 const bad=new FormData();bad.set('environment','prod');bad.set('confirmation','wrong');bad.set('file',new File([zip],'shop.zip'));
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/deploy',{method:'POST',headers:{...authHeaders,Origin:'https://deploy.sooae.kr','X-Sooae-Action':'1'},body:bad}),env);
 assert.equal(res.status,400,'production typed approval required');
 // Full mock ZIP deployment must call Cloudflare hash check, upsert and deployment creation.
 const data=new FormData();data.set('environment','dev');data.set('confirmation','DEPLOY DEV');data.set('file',new File([zip],'shop.zip'));
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/deploy',{method:'POST',headers:{...authHeaders,Origin:'https://deploy.sooae.kr','X-Sooae-Action':'1'},body:data}),env);
 assert.equal(res.status,200,'mock deploy request: '+await res.clone().text());
 const names=recorded.map(x=>x.pathname);
 for(const route of ['/pages/assets/check-missing','/pages/assets/upsert-hashes'])assert(names.some(x=>x.endsWith(route)),route);
 assert(names.some(x=>x.endsWith('/deployments')));
 const sqlData=new FormData();sqlData.set('environment','dev');sqlData.set('confirmation','SQL DEV');sqlData.set('file',new File([new TextEncoder().encode('CREATE TABLE IF NOT EXISTS x (id INTEGER PRIMARY KEY);')],'update.sql'));
 res=await mod.default.fetch(new Request('https://deploy.sooae.kr/api/sql',{method:'POST',headers:{...authHeaders,Origin:'https://deploy.sooae.kr','X-Sooae-Action':'1'},body:sqlData}),env);
 assert.equal(res.status,200,'SQL request '+await res.clone().text());
 console.log('PASS: ZIP extraction (all '+files.length+' files), damaged archive, path traversal, HTML, login/session, origin protection, production confirmation, Cloudflare Pages mock upload, D1 mock SQL');
}finally{globalThis.fetch=fetchOriginal;fs.rmSync(tmp,{force:true,recursive:true});}
